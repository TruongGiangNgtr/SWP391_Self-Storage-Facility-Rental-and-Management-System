using Microsoft.EntityFrameworkCore.Migrations;

namespace Frms.DataAccess.Migrations;

public sealed partial class ReservationCancellation : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        // Source has no prior definition. CREATE deliberately refuses to overwrite
        // an out-of-band procedure whose business behavior has not been reviewed.
        // CREATE must be first in its own SQL batch, including EF idempotent scripts.
        migrationBuilder.Sql("EXEC(N'" + CreateProcedureSql.Replace("'", "''", StringComparison.Ordinal) + "');");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Removes only the SQL object introduced here; historical rows remain intact.
        // Up can redeploy the same procedure without rewriting business data.
        migrationBuilder.Sql("DROP PROCEDURE dbo.usp_CancelReservation;");
    }

    private const string CreateProcedureSql = """
        CREATE PROCEDURE dbo.usp_CancelReservation
            @UserAccountId uniqueidentifier,
            @CustomerId uniqueidentifier,
            @ReservationId uniqueidentifier
        AS
        BEGIN
            SET NOCOUNT ON;
            SET XACT_ABORT ON;
            BEGIN TRY
                BEGIN TRANSACTION;

                DECLARE @Status varchar(50), @OwnerId uniqueidentifier;
                SELECT @Status = Status, @OwnerId = CustomerId
                FROM dbo.Reservation WITH (UPDLOCK, HOLDLOCK)
                WHERE ReservationId = @ReservationId;
                IF @Status IS NULL OR @OwnerId <> @CustomerId
                    THROW 51201, 'RESOURCE_NOT_FOUND', 1;

                DECLARE @AccountStatus varchar(50), @Role varchar(50);
                SELECT @AccountStatus = a.Status, @Role = r.RoleName
                FROM dbo.Customer c WITH (HOLDLOCK)
                JOIN dbo.UserAccount a WITH (HOLDLOCK) ON a.UserAccountId = c.UserAccountId
                JOIN dbo.UserRole r WITH (HOLDLOCK) ON r.RoleId = a.RoleId
                WHERE c.CustomerId = @CustomerId AND a.UserAccountId = @UserAccountId;
                IF @AccountStatus IS NULL
                    THROW 51201, 'RESOURCE_NOT_FOUND', 1;
                IF @AccountStatus <> 'ACTIVE'
                    THROW 51202, 'ACCOUNT_INACTIVE', 1;
                IF @Role <> 'CUSTOMER'
                    THROW 51203, 'FORBIDDEN', 1;

                IF @Status NOT IN ('PENDING_DEPOSIT', 'CONFIRMED', 'CANCELLED')
                    THROW 51204, 'RESERVATION_INVALID_STATUS', 1;

                -- Lock both existing visits and the absent-visit range against
                -- concurrent confirm/check-in, and reject any handover history.
                IF EXISTS (
                    SELECT 1 FROM dbo.Visit WITH (UPDLOCK, HOLDLOCK)
                    WHERE EntityId = @ReservationId AND VisitType = 'RESERVATION'
                        AND Status IN ('CHECKED_IN', 'CHECKED_OUT')
                )
                    THROW 51205, 'VISIT_INVALID_STATUS', 1;
                IF EXISTS (
                    SELECT 1 FROM dbo.Contract WITH (UPDLOCK, HOLDLOCK)
                    WHERE ReservationId = @ReservationId
                )
                    THROW 51204, 'RESERVATION_INVALID_STATUS', 1;

                UPDATE dbo.Visit SET Status = 'CANCELLED'
                WHERE EntityId = @ReservationId AND VisitType = 'RESERVATION'
                    AND Status = 'SCHEDULED';
                UPDATE dbo.Reservation SET Status = 'CANCELLED'
                WHERE ReservationId = @ReservationId
                    AND Status IN ('PENDING_DEPOSIT', 'CONFIRMED');
                -- CapacityRepository excludes CANCELLED holds. There is no
                -- capacity counter to decrement, including on an idempotent retry.
                -- Invoice/Payment and physical StorageUnit are never changed.
                COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
                THROW;
            END CATCH
        END;
        """;
}
