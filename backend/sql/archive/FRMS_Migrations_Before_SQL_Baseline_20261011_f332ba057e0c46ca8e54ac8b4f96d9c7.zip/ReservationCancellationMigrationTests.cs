using Frms.DataAccess.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Frms.IntegrationTests;

// SQL script/model checks do not establish SQL Server execution or locking evidence.
[TestFixture]
public sealed class ReservationCancellationMigrationTests
{
    [Test]
    public void DBT_PROC_SCRIPT_001_UpgradeRollbackAndModelAreProcedureOnly()
    {
        using var context = new FrmsDbContext(new DbContextOptionsBuilder<FrmsDbContext>().UseSqlServer().Options);
        var migrator = context.GetService<IMigrator>();
        var forward = migrator.GenerateScript("20261010120000_ReservationCancellation",
            "20261011090000_ReservationVisitProcedures", MigrationsSqlGenerationOptions.Idempotent);
        var rollback = migrator.GenerateScript("20261011090000_ReservationVisitProcedures",
            "20261010120000_ReservationCancellation");
        Assert.Multiple(() =>
        {
            Assert.That(forward, Does.Contain("EXEC(N'CREATE PROCEDURE dbo.usp_ConfirmReservation"));
            Assert.That(forward, Does.Contain("EXEC(N'CREATE PROCEDURE dbo.usp_CheckInVisit"));
            Assert.That(forward, Does.Contain("DATEADD(hour, 7, SYSUTCDATETIME())"));
            Assert.That(forward, Does.Not.Contain("CREATE TABLE").And.Not.Contain("ALTER TABLE"));
            Assert.That(forward, Does.Not.Contain("UPDATE dbo.Invoice").And.Not.Contain("UPDATE dbo.Payment"));
            Assert.That(rollback, Does.Contain("DROP PROCEDURE dbo.usp_CheckInVisit;").And.Contain("DROP PROCEDURE dbo.usp_ConfirmReservation;"));
            // EF legitimately removes its own migration-history row on downgrade.
            Assert.That(rollback, Does.Not.Contain("DELETE FROM dbo.Visit").And.Not.Contain("DELETE FROM dbo.Reservation"));
        });
        var migrations = context.GetService<IMigrationsAssembly>();
        var before = migrations.CreateMigration(migrations.Migrations["20261010120000_ReservationCancellation"], context.Database.ProviderName!);
        var after = migrations.CreateMigration(migrations.Migrations["20261011090000_ReservationVisitProcedures"], context.Database.ProviderName!);
        var initializer = context.GetService<IModelRuntimeInitializer>();
        var oldModel = initializer.Initialize(before.TargetModel, designTime: true);
        var newModel = initializer.Initialize(after.TargetModel, designTime: true);
        Assert.That(newModel.GetEntityTypes().Count(), Is.EqualTo(27));
        Assert.That(context.GetService<IMigrationsModelDiffer>().GetDifferences(oldModel.GetRelationalModel(), newModel.GetRelationalModel()), Is.Empty);
    }

    [Test]
    public void DBT_RES005_SCRIPT_001_UpgradeAndRollbackContainOnlyTheNewProcedure()
    {
        using var context = new FrmsDbContext(new DbContextOptionsBuilder<FrmsDbContext>().UseSqlServer().Options);
        var migrator = context.GetService<IMigrator>();
        var forward = migrator.GenerateScript("20261008191750_PayOsPaymentGateway",
            "20261010120000_ReservationCancellation", MigrationsSqlGenerationOptions.Idempotent);
        var rollback = migrator.GenerateScript("20261010120000_ReservationCancellation",
            "20261008191750_PayOsPaymentGateway");
        Assert.Multiple(() =>
        {
            Assert.That(forward, Does.Contain("EXEC(N'CREATE PROCEDURE dbo.usp_CancelReservation"));
            Assert.That(forward, Does.Contain("UPDLOCK, HOLDLOCK"));
            Assert.That(forward, Does.Contain("ROLLBACK TRANSACTION"));
            Assert.That(forward, Does.Contain("20261010120000_ReservationCancellation"));
            Assert.That(forward, Does.Not.Contain("UPDATE dbo.Invoice").And.Not.Contain("UPDATE dbo.Payment"));
            Assert.That(forward, Does.Not.Contain("CREATE TABLE").And.Not.Contain("ALTER TABLE"));
            Assert.That(rollback, Does.Contain("DROP PROCEDURE dbo.usp_CancelReservation;"));
            Assert.That(rollback, Does.Not.Contain("DELETE FROM dbo.Reservation").And.Not.Contain("DELETE FROM dbo.Visit"));
        });
    }

    [Test]
    public void DBT_RES005_SCRIPT_002_TargetModelPreservesAllExistingEntitiesAndColumns()
    {
        using var context = new FrmsDbContext(new DbContextOptionsBuilder<FrmsDbContext>().UseSqlServer().Options);
        var migrations = context.GetService<IMigrationsAssembly>();
        var previous = migrations.CreateMigration(migrations.Migrations["20261008191750_PayOsPaymentGateway"], context.Database.ProviderName!);
        var added = migrations.CreateMigration(migrations.Migrations["20261010120000_ReservationCancellation"], context.Database.ProviderName!);
        Assert.That(added.TargetModel.GetEntityTypes().Count(), Is.EqualTo(27));
        var initializer = context.GetService<Microsoft.EntityFrameworkCore.Infrastructure.IModelRuntimeInitializer>();
        var oldModel = initializer.Initialize(previous.TargetModel, designTime: true);
        var newModel = initializer.Initialize(added.TargetModel, designTime: true);
        var differences = context.GetService<IMigrationsModelDiffer>().GetDifferences(oldModel.GetRelationalModel(), newModel.GetRelationalModel());
        Assert.That(differences, Is.Empty);
    }
}
